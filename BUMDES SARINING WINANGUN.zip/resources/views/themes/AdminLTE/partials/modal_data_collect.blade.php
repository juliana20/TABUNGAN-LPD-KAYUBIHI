<div class="modal" id="data-collect-modal" tabindex="-1" role="dialog" aria-labelledby="data-collect-modal" aria-hidden="true">
    <div class="modal-dialog" style="display:table" role="document">
        <div class="modal-content">
            <div class="modal-header modal-header-info">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                <h4 class="modal-title" id="data-collect-modal-title"><strong></strong></h4>
            </div>
            <div class="modal-body"></div>
      <div class="modal-footer">
        <div class="row">
          <div class="col-md-6">
            <button id="data-collect-modal-close" type="button" class="btn btn-block btn-default" data-dismiss="modal" aria-label="Close"></button>
          </div>
          <div class="col-md-6">
            <button id="data-collect-modal-select" type="button" class="btn btn-block btn-info"></button>
          </div>
        </div>
      </div>
        </div>
    </div>
  </div>